package test.nz.ac.massey.cs.guery.adapters.blueprints;

import org.neo4j.graphdb.RelationshipType;

public enum RelTypes implements RelationshipType {
	EXTENDS, IMPLEMENTS, USES

}
