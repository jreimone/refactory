package nz.ac.massey.cs.guery.impl;

import java.util.Iterator;

import nz.ac.massey.cs.guery.Path;

public class CachedLazyPathIterator<V,E> implements Iterator<Path<V,E>>{

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Path<V, E> next() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub
		
	}

}
