package nz.ac.massey.cs.guery.impl;

public interface GQLMonitorMBean {
	public int getVertexCount ();
	
	public int getProcessedVertexCount ();
	
	
}
